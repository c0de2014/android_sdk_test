silvertunnel.org Netlib - Java library to easily access anonymity networks
--------------------------------------------------------------------------
Copyright (c) 2009-2012 silvertunnel.org


Netlib is (will hopefully be) an easy to use Java library to access the
Tor anonymity network with as few dependencies as possible to simplify
usage of the lib. For Java developers.

How to start with silvertunnel.org Netlib: see
 * https://silvertunnel.org/netlib.html
 * https://silvertunnel.org/doc/netlib-introduction.html

License: see
 * GPL_LICENSE.txt

We hope this library is useful for you.

With best regards

Christian Hapke
silvertunnel.org
